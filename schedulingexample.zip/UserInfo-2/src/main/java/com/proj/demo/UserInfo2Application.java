package com.proj.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class UserInfo2Application {

	public static void main(String[] args) {
		SpringApplication.run(UserInfo2Application.class, args);
	}

}
